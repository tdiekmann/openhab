/** 
 * -----------------------------------------------------------------
 * ISYOpenADRClientApp.java
 * Author: MKohanim
 * Jun 12, 2013 - 1:00:36 AM
 * --------------
 *
 * An example for an OpenADR Client for ISY
 * -----------------------------------------------------------------
 * Copyright (C) 2007-2013  Universal Devices
 * -----------------------------------------------------------------
 */
package example;

import com.nanoxml.XMLElement;
import com.universaldevices.common.Constants;
import com.universaldevices.device.model.elec.IElectricityListener;
import com.universaldevices.device.model.elec.oadr.AutoDRConfig;
import com.universaldevices.device.model.elec.oadr.EiEvent;
import com.universaldevices.device.model.elec.oadr.EiEvents;
import com.universaldevices.device.model.elec.oadr.OADROpt;
import com.universaldevices.device.model.elec.oadr.OADRRegistrationEvent;
import com.universaldevices.device.model.elec.oadr.OADRReport;
import com.universaldevices.device.model.elec.oadr.OpenADRState;
import com.universaldevices.resources.errormessages.Errors;
import com.universaldevices.rest.UDRestResponse;
import com.universaldevices.upnp.UDControlPoint;


/**
 * 
 */
public class ISYOpenADRClientApp implements IElectricityListener{
	
	private MyISYInsteonClient myISY = null;
	private OpenADRState currentState = null;
	
	public ISYOpenADRClientApp()
	{
		myISY=new MyISYInsteonClient();
		Errors.addErrorListener(new MyISYErrorHandler());
	}
	
	public synchronized MyISYInsteonClient getISY()
	{
		return myISY;
	}

	/**
	 * IElectricityListener
	 */
	@Override
	public void onFYPError() {
		System.err.println("FYP - Not Implemented");
		
	}

	@Override
	public void onFYPStatus(boolean arg0) {
		System.err.println("FYP - Not Implemented");
	}

	@Override
	public void onOpenADRError() {
		System.err.println("oOohhh - We have an OpenADR Error ... check VTN!");
	}

	@Override
	public void onOpenADRStatus(OpenADRState oadrEvent) {
		currentState = oadrEvent;
		System.out.println("Finally! An OpenADR Event for us");
		System.out.println(String.format("Profile = %s", oadrEvent.isProfile1()?"1":"2"));
		System.out.println(String.format("Status = %s", oadrEvent.status));
		System.out.println(String.format("Mode = %s", oadrEvent.mode));
		System.out.println(String.format("Start Time = %s", oadrEvent.startTime));
		System.out.println(String.format("End Time = %s", oadrEvent.endTime));
	}
	
	/**
	 * Retrieves the configuration file
	 * @return AutoDRConfig
	 */
	private AutoDRConfig getConfiguration()
	{
		if (getISY().getDevice()==null || !getISY().getDevice().isCommunicatable())
			return null;
		byte[] ac= getISY().getDevice().getSystemConfigurationFile(AutoDRConfig.AUTO_DR_CONFIG_FILE);
		if (ac == null)
		  return null;
		AutoDRConfig adc = new AutoDRConfig(new String(ac));
		return adc;
	}
	
	/**
	 * Saves the configuration file
	 * @param - AutoDRConfig
	 * @return - whether or not successful
	 */
	private  boolean saveConfiguration(AutoDRConfig adc)
	{
		if (getISY().getDevice()==null || !getISY().getDevice().isCommunicatable())
			return false;
		/**
		 * Same as /file/upload/CONF/ADR.CFG?load=y
		 */
		return getISY().getDevice().saveSystemConfigurationFile(AutoDRConfig.AUTO_DR_CONFIG_FILE, adc.toDIML().toString(),Constants.FILE_PROCESS_FLAG);
	}
	
	/**
	 * Gets all the events from ISY
	 * @return - EiEvents
	 */
	private EiEvents getAllEvents()
	{
		if (getISY().getDevice()==null || !getISY().getDevice().isCommunicatable())
			return null;
		EiEvents events = null;
		UDRestResponse resp = getISY().getDevice().submitRESTRequest(EiEvents.EI_EVENTS_URL);
		if (resp != null && resp.isSucceeded())
		{
			try
			{
				XMLElement xml = new XMLElement();
				xml.parseString(resp.getBody());
				events = new EiEvents(xml);
				}catch(Exception e)
				{
					e.printStackTrace();
				}
		}
		return events;
	}
	
	/**
	 * Clears all the events from ISY
	 * @return - Whether or not successful 
	 */
	private boolean clearAllEvents()
	{
		if (getISY().getDevice()==null || !getISY().getDevice().isCommunicatable())
			return false;
		UDRestResponse resp = getISY().getDevice().submitRESTRequest(EiEvents.EI_EVENTS_CLEAR_URL);
		if (resp == null)
			return false;
		return resp.isSucceeded();
	}
	
	/**
	 * Opts in or out of an event
	 * @param event - the event to which we want to opt in/out
	 * @param opt - whether or not we are opting in
	 * @return - Whether or not successful 
	 */
	private boolean setDisposition(EiEvent event, boolean opt)
	{
		if (getISY().getDevice()==null || !getISY().getDevice().isCommunicatable())
			return false;
		String url = EiEvents.getOptURL(event, opt);
		if (url == null)
			return false;
		UDRestResponse resp = getISY().getDevice().submitRESTRequest(url);
		if (resp == null)
			return false;
		return resp.isSucceeded();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		final ISYOpenADRClientApp app = new ISYOpenADRClientApp();
		
		
		try{
			if (args.length == 0)
				app.getISY().start();
			else if (args.length == 2)
				app.getISY().start(args[0], args[1]); 
			else
			{
				System.err.println("usage: ISYOpenADRClientApp ([uuid][url])|(no args for UPnP)");
				System.exit(1);
			}
			
			while (true)
			{
				if (app.getISY().getDevice() == null || !app.getISY().isStarted())
				{
					System.err.println("Not started ... ");
					Thread.sleep(1000);
				}
				else
					break;
			}
			
			/**
			 * Let's get the OADR configuration file
			 */
			AutoDRConfig config = app.getConfiguration();
			
			/**
			 * Modify it and save it
			 */
			app.saveConfiguration(config);
			
			/**
			 * We want to be notified of OpenADR events, so, let's register for IElectricityListener events
			 */
			
			UDControlPoint.getInstance().addElectricityListener(app);
			
			while (true)
			{
				//do some random things!!!
				while(app.currentState == null)
					Thread.sleep(2000);
				if (app.currentState.status.equals("Active"))
				{
					EiEvents events = app.getAllEvents();
					if (events != null && events.size() > 0)
					{
						EiEvent event = events.get(1); //get the first event
						app.setDisposition(event, true); //opt in to it
						
						/***
						 * to Opt out:
						 */
						//app.setDisposition(event, true); //opt in to it
						
						/***
						 * To clear all events
						 */
						//app.clearAllEvents();
					}
				}
				
				Thread.sleep(2000); //take a nap
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see com.universaldevices.device.model.elec.IElectricityListener#onOADROptChanged(com.universaldevices.device.model.elec.oadr.OADROpt)
	 */
	@Override
	public void onOADROptChanged(OADROpt arg0) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.universaldevices.device.model.elec.IElectricityListener#onOADRRegistrationChanged(com.universaldevices.device.model.elec.oadr.OADRRegistrationEvent)
	 */
	@Override
	public void onOADRRegistrationChanged(OADRRegistrationEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.universaldevices.device.model.elec.IElectricityListener#onOADRReportChanged(com.universaldevices.device.model.elec.oadr.OADRReport)
	 */
	@Override
	public void onOADRReportChanged(OADRReport arg0) {
		// TODO Auto-generated method stub
		
	}

		
}


/*
*********************************************************************************************************
*                                           REVISION HISTORY
*
* $Log: ISYOpenADRClientApp.java,v $
* Revision 1.3  2014/04/13 20:09:48  mkohanim
* 4.2 support
*
* Revision 1.2  2013/06/12 08:51:26  mkohanim
* Added get/saveConfiguration
*
* Revision 1.1  2013/06/12 08:35:39  mkohanim
* Initial
*
* 
*********************************************************************************************************
*/