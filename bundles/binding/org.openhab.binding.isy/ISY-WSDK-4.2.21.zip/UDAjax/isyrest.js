/*
*  ISY994 REST Interface js
*  Author: Benoit Mercier
*    
*  This library provides a set of generic functions for the dashboard
*/

var firmwareVersion = "4.1.3" // Used to start the appropriate UI

var devListDefault = []; // Default device table built from /rest/nodes
var varListDefault = []; // Default variable table
var pgmListDefault = []; // Default program table

var automaticDevRefreshActive=0;  // Will be set to 1 if active.
var automaticDevRefreshTimeoutTimer=0;  // Will be set to the current active timeout, coming from setTimeout

var features = { } // Initialized by processConfig. This structure will change in a future version. Don't rely on it for now.
// Available properties:
//	isWeatherInstalled
//	isNetworkInstalled
//  isIrrigationInstalled
//  isELKInstalled
//	isZWaveInstalled


var ClimCoverage = [
	"",
	"Areas of",
	"Brief",
	"Chance of",
	"Definite",
	"Frequent",
	"Intermittent",
	"Isolated",
	"Likely",
	"Numerous",
	"Occasional",
	"Patchy",
	"Periods of",
	"Slight chance of",
	"Scattered",
	"Nearby",
	"Widespread" ];

var ClimIntensity = [
	"",
	"Very light",
	"Light",
	"Heavy",
	"Very heavy" ];
	

var ClimWeatherConditions = [
	"",
	"Hail",
	"Blowing dust",
	"Blowing sand",
	"Mist",
	"Blowing snow",
	"Fog",
	"Frost",
	"Haze",
	"Ice Crystals",
	"Ice fog",
	"Ice pellets / sleet",
	"Smoke",
	"Drizzle",
	"Rain",
	"Rain showers",
	"Rain/snow mix",
	"Snow/sleet mix",
	"Wintry mix",
	"Snow",
	"Snow showers",
	"Thunderstorms",
	"Unknown Precipitation",
	"Volcanic ash",
	"Water spouts",
	"Freezing fog",
	"Freezing drizzle",
	"Freezing rain",
	"Freezing spray" ];

var ClimCloudConditions = [
	"",
	"Clear	(0-7% of the sky)",
	"Fair/mostly sunny	(7-32%)",
	"Partly cloudy	(32-70%)",
	"Mostly cloudy	(70-95%)",
	"Cloudy" ];


function init()
{ 
	// Initialises the tab UI, and set events for when tab are switched
	$("#tabs").tabs({ create: tabCreated, activate: tabActivated }); 

	UDFinit();
}


// Will call UDFdevLoaded(devdata) when complete
function restCallConfig() 
{
	// Inits the config from /rest/config
	var deferredConfig = ajaxCall("/rest/config", true); // Reads the list of nodes

	deferredConfig.done(function(confdata, status, jqXHR){
		UDFconfigLoaded(confdata);
	});
}



// Will call UDFdevLoaded(devdata) when complete
function restCallNodes() 
{
	var urldev="/rest/nodes";
	var deferredNodes = ajaxCall(urldev, true); // Reads the list of nodes
	
	// This is what will run when /rest/nodes is successful
	deferredNodes.done(function(devdata, status, jqXHR){
		UDFdevLoaded(devdata); // Runs User Defined function

		$("[nicebutton]").button(); // All buttons that have the attribute "nicebutton" will have the same jQueryUI classes	
		initDevSliders();			// Inits the device sliders
		initStatSpinner(devdata);	// Inits thermostat controls	
	
		//	Updates all the device status from the recently downloaded data (No need to fetch it again)
		$(devdata).find('node').each(function() { 
			deviceDisplay(this);
		});

		UDFdevLoadedPostUI(devdata)
	});	


	// This is what will run when /rest/nodes is NOT successful.
	deferredNodes.fail(function(jqXHR, status, error){
		feedbackErrURL(urldev, error);
		if ($.isFunction(UDFdevLoadingError))
		{
			UDFdevLoadingError(); // Still display the table, but with no data.
		}
	});	
	
	return deferredNodes;
}






// Will call UDFvarsDefLoaded(var1defs, var2defs) when complete
function restCallVarsDef(loadVar1Defs, loadVar2Defs) // Load integer, Load state
{
	var deferredVars1def=null;
	var deferredVars2def=null;
	var deferredVarsDefWhen;
	
	if (loadVar1Defs) // If enabled, start this Ajax request ASAP, it will run in parallel with the current thread.
	{
		var urlvar1 = "/rest/vars/definitions/1";
		deferredVars1def = ajaxCall(urlvar1, true); // Reads the list of variables of type integer 

		deferredVars1def.fail(function(jqXHR, status, error){
			feedbackErrURL(urlvar1, error);
			});	
	}

	if (loadVar2Defs) // If enabled, start this Ajax request ASAP, it will run in parallel with the current thread.
	{
		var urlvar2 = "/rest/vars/definitions/2";		
		deferredVars2def = ajaxCall(urlvar2, true); // Reads the list of variables of type state
	
		deferredVars2def.fail(function(jqXHR, status, error){
			feedbackErrURL(urlvar2, error);
		});	
	}
	
	deferredVarsDefWhen = $.when(deferredVars1def, deferredVars2def)
	
	deferredVarsDefWhen.done(function(vars1Argsdef, vars2Argsdef){
		var var1defs;
		var var2defs;
				
		if (vars1Argsdef)
		{ var1defs = vars1Argsdef[0]; }
		else
		{ var1defs = null; }
		
		if (vars2Argsdef)
		{ var2defs = vars2Argsdef[0]; }
		else
		{ var2defs = null; }				
	
		UDFvarsDefLoaded(var1defs, var2defs); // Runs User Defined function
	});	
	
	return deferredVarsDefWhen;
}


// Will call deferredVarsDataWhen(var1data, var2data, var1def, var2def) when complete
function restCallVarsData(loadVar1Data, loadVar2Data, deferredVarsDefWhen) // Load integer, Load state
{
	var deferredVars1data=null;
	var deferredVars2data=null;	
	var deferredVarsDataWhen;
	
	if (loadVar1Data) // If enabled, start this Ajax request ASAP, it will run in parallel with the current thread.
	{
		var urlvar1 = "/rest/vars/get/1";
		deferredVars1data = ajaxCall(urlvar1, true); // Reads the variables of type integer 
	
		deferredVars1data.fail(function(jqXHR, status, error){
			feedbackErrURL(urlvar1, error);
		});	
	}
	
	if (loadVar2Data) // If enabled, start this Ajax request ASAP, it will run in parallel with the current thread.
	{
		var urlvar2 = "/rest/vars/get/2";		
		deferredVars2data = ajaxCall(urlvar2, true); // Reads the variables of type state
	
		deferredVars2data.fail(function(jqXHR, status, error){
			feedbackErrURL(urlvar2, error);
		});	
	}
	
	deferredVarsDataWhen = $.when(deferredVars1data, deferredVars2data, deferredVarsDefWhen);
	
	deferredVarsDataWhen.done(function(vars1Argsdata, vars2Argsdata, varsArgsDefWhen){
		var var1data=null;
		var var2data=null;
		var var1def=null;
		var var2def=null;
				
		if (vars1Argsdata)
		{ var1data = vars1Argsdata[0]; }
				
		if (vars2Argsdata)
		{ var2data = vars2Argsdata[0]; }
				
		if (varsArgsDefWhen)
		{
			if (varsArgsDefWhen[0])
			{ var1defs = varsArgsDefWhen[0][0]; }
				
			if (varsArgsDefWhen[1])
			{ var2defs = varsArgsDefWhen[1][0]; }
		}

		UDFvarDataLoaded(var1data, var2data, var1def, var2def); // Runs User Defined function
	});
	
	return deferredVarsDataWhen;
}


// Will call UDFpgmLoaded(pgmData, var1defs, var2defs) when complete
function restCallPgms(deferredVarsDefWhen)
{
	var urlpgm = "/rest/programs/?subfolders=true";
	var deferredPgm = ajaxCall(urlpgm, true); // Reads the list of Pgms		
			
	deferredPgm.fail(function(jqXHR, status, error){
		feedbackErrURL(urlpgm, error);
	});	
	
	// As soon as the calls for variables and programs are complete, we can update the HTML where appropriate
	// This can run in parallel with completeInit.	
	// If variable defs were requested, "When" will wait for completion. Otherwise, it will just pass the default values (0);
	$.when(deferredPgm, deferredVarsDefWhen).done(function(pgmArgs, varsArgsDefWhen){
		var var1defs=null;
		var var2defs=null;

		if (varsArgsDefWhen)
		{
			if (varsArgsDefWhen[0])
			{ var1defs = varsArgsDefWhen[0][0]; }
			
			if (varsArgsDefWhen[1])
			{ var2defs = varsArgsDefWhen[1][0]; }
		}

		UDFpgmLoaded(pgmArgs[0], var1defs, var2defs); // Runs User Defined function
	});
	
	return deferredPgm;
}







function processConfig(confdata)
{
	$(confdata).find('feature').each(function() {
		var id = $(this).children("id").text();

		if (id=="21020") {
			features.isWeatherInstalled = $(this).children("isInstalled").text()=="true";
		}
		else if (id=="21040") {
			features.isNetworkInstalled = $(this).children("isInstalled").text()=="true";
		}			
		else if (id=="23000") {
			features.isIrrigationInstalled = $(this).children("isInstalled").text()=="true";
		}
		else if (id=="21090") {
			features.isELKInstalled = $(this).children("isInstalled").text()=="true";
		}
		else if (id=="21100") {
			features.isZWaveInstalled = $(this).children("isInstalled").text()=="true";
		}
	});
}


// The tabActivated event is not run on initial tab creation, so we trap the creation here and allow tabActivated to run.
function tabCreated(event, ui)   
{
	ui.newPanel = ui.panel;  // The activate event works with newPanel, not panel
	ui.oldPanel = null;	
	tabActivated(event, ui);
}

function tabActivated(event, ui)   
{
	if ($.isFunction(UDFtabActivated))
	{
		UDFtabActivated(event, ui);
	}
}



// Adjust table options based on Insteon/ZWave specific devices
// Used for both the generic device table and custom tables
function adjustNodesExceptions(tableItem)
{
	var catControl=0;
	var subcatControl=0;
	var catSubcatControl="";
	var add4 = tableItem.addressControl.split(" ")[3]; // Retrieves the 4th number of the address
	
	tableItem.id = tableItem.address.replace(/\ /g,'_'); // This will be the ID where status is displayed
	
	if (tableItem.devTypeCtl)
	{
		catControl = parseInt(tableItem.devTypeCtl.split(".")[0]);
		subcatControl = parseInt(tableItem.devTypeCtl.split(".")[1]);
		catSubcatControl = catControl + "." + subcatControl; // example: "4.18"
	}
	else
	{
		tableItem.devTypeCtl="";
	}

	if (catControl==1) // This is an insteon dimmer
	{
		tableItem.dimmer255=1;  // Add the dimmer on a scale of 0-255
	}
	else if (catSubcatControl == "4.17")  // This is a Zwave dimmer
	{
		tableItem.dimmer100=1;  // Add the dimmer on a scale of 0-100
	}
	else if (catSubcatControl == "7.9")  // SynchroLinc
	{
		if (!tableItem.hideControls)  // If defined explicitly, don't touch it, else default to "Yes"
		{
			tableItem.hideControls="Yes";
		}
	}
	// This is a thermostat. 4.8 Trane, 5.3 venstar, 5.10 Insteon Wireless, 5.11 Insteon, 5.17 Insteon (EU), 5.18 Insteon (Aus/NZ)
	else if ($.inArray(catSubcatControl, ["4.8", "5.3", "5.10", "5.11", "5.17", "5.18"])!=-1)  
	{
		tableItem.specControls="stat";
	}
	else if (catSubcatControl == "0.5")  // This is a remote
	{
		if (!tableItem.hideControls)   // If defined explicitly, don't touch it, else default to "Yes"
		{
			tableItem.hideControls="Yes";
		}
	}
	else if (catSubcatControl == "7.0")  // This is an IOLinc
	{
		if (!tableItem.hideControls && add4=="1") // 1 means it's the sensor of the IO Linc
		{
			tableItem.hideControls="Yes";
		}
	}
	else if (catSubcatControl == "4.64") // Kwikset or Yale doorlock
	{
			tableItem.specControls="doorlock";
	}
}


//This is called only if this is a thermostat
function adjustThermostatExceptions(tableitem, xmlnode)
{
	ST = $(xmlnode).find("#ST");
	value = ST.attr("value");
	formatted = ST.attr("formatted");

	tableitem.statMultiplier = (parseFloat(value) == parseFloat(formatted)*2)?2:1;
	
//  Simulate a multiplier	
//	tableitem.statMultiplier = 2;
//	console.log("Multiplier: " + tableitem.statMultiplier);
}



// ---------- Set of functions to build the generic device table ----------

// Builds a device table from scratch based on /rest/nodes
function tableBuildDeviceList(xmldata, deviceList, folder) // Fills the table with node data, in preparation for display 
{
	nodes = $(xmldata).find('node');
	scenes = $(xmldata).find('group');	
	folders = $(xmldata).find('folder');

	// If a specific folder is requested other than "", create a section and add corresponding 
	if (folder && folder !="") 
	{
		//If it finds it
		folders.find("name:contains('"+ folder +"')").parent().each(function() {
			section = new Object();
			section.location = folder
			section.list = [];
			
			folderAddToTableProcess.call(this);  // Calls folderProcess within the context of this node
	
			if (section.list.length>0);  // If there was at least one, include the section.
			{
				section.list.sort(sortBy);
				deviceList.push(section);
			}
		});
	}
	
	// If no specific folder is requested, or if the "" folder is requested, 
	// create a section "My Lighting" with nodes not in a folder
	if (folder=="" || folder=="All") 
	{
		// Find nodes without parents and include it in a section "My Lighting"	
		section = new Object();
		section.location = "My Lighting"; 
		section.list = [];
	
		nodes.each(function() {
			if ($(this).children("parent").text()=="")
			{
				nodeAddToTableProcess.call(this);  // Add the node to the table
			}	
		});
	
		if (section.list.length>0)  // If there was at least one, include the section.
		{
			section.list.sort(sortBy);
			deviceList.push(section);
		}
	}

	// If no specific folder is requested create a section for each main folders
	if (folder=="All")
	{
		// Loops through folders to create one section per main folder
		folders.each(function() {
			section = new Object();
	
			section.location = $(this).children("name").text();
			section.list = [];
			
			if ($(this).children("parent").text()=="") // This is a main folder, we will process it. 
			{			
				folderAddToTableProcess.call(this);  // Calls folderProcess within the context of this node

				if (section.list.length>0);  // If there was at least one, include the section.
				{
					section.list.sort(sortBy);
					deviceList.push(section);
				}
			}
		});
	}
}



function folderAddToTableProcess()
{
	var folderAddress = $(this).children("address").text();

	// Finds all nodes whose parent is the current folder and add it to the table
	nodes.find("parent:contains('"+ folderAddress +"')").parent().each(nodeAddToTableProcess);		

	// Finds all nodes whose parent is the current folder and add it to the table
	scenes.find("parent:contains('"+ folderAddress +"')").parent().each(sceneAddToTableProcess);		

	// Finds all folders whose parent is the current folder and add it's nodes to the table recursively
	folders.find("parent:contains('"+ folderAddress +"')").parent().each(folderAddToTableProcess);		
}


function nodeAddToTableProcess() 
{
	var node = new Object();					

	node.name = node.control = $(this).children("name").text();
	node.devType = node.devTypeCtl = $(this).children('type').text();			
	node.address = $(this).children('address').text();	
	node.addressControl = node.address;			
	adjustNodesExceptions(node);

	
	if (node.specControls=="stat") // For best performance, we isolate stat processing here.
	{
		adjustThermostatExceptions(node, this);	// Pass the tableitem, and the /rest/nodes node
	}
		
	section.list.push(node);
}



function sceneAddToTableProcess() 
{
	var node = new Object();					
	
	node.name = node.control = $(this).children("name").text();
	node.devType = "";				
	node.catControl = 0; 
	node.refreshOpt = "No"; 	
	node.address = $(this).children('address').text();	
	node.addressControl = node.address;				
	node.id = node.address.replace(/\ /g,'_');
	section.list.push(node);
}


// ---------- Set of functions to build the generic program table ----------


// Builds a device table from scratch based on /rest/nodes
function tableBuildPgmList(xmldata, deviceList, folder) // Fills the table with node data, in preparation for display 
{
	rootFolderId = $(xmldata).find('program[folder="true"]:not([parentId])').first().attr("id"); // The root folder is the one without a parentId.
	programs = $(xmldata).find('program[folder="false"]');
	folders = $(xmldata).find('program[folder="true"]');
	mainfolders = $(xmldata).find('program[folder="true"][parentId="' + rootFolderId + '"]');

	// If no specific folder is requested create a section for each main folders
	if (folder=="All")
	{
		// Loops through folders to create one section per main folder
		mainfolders.each(function() {
			section = new Object();

			section.location = $(this).children("name").text();
			section.list = [];
			
			folderPgmAddToTableProcess.call(this);  // Calls folderProcess within the context of this node

			if (section.list.length>0);  // If there was at least one, include the section.
			{
				section.list.sort(sortBy);
				deviceList.push(section);
			}
		});
	}
}


function folderPgmAddToTableProcess() // Adds pgm nodes from this folder to the table, and look into subfolders
{
	pgmId = $(this).attr("id");

	// Finds all nodes whose parent is the current folder and add it to the table
	programs.filter('[parentId="' + pgmId + '"]').each(nodePgmAddToTableProcess);		

	// Finds all folders whose parent is the current folder and add it's nodes to the table recursively
	folders.filter('[parentId="' + pgmId + '"]').each(folderPgmAddToTableProcess);		
}


function nodePgmAddToTableProcess() // Adds pgm node to the table 
{
	node = new Object();					

	node.name = $(this).children("name").text(); // label displayed on screen
	node.programId = $(this).attr("id"); 		// Retrive the programId
	node.typeControl = typeControl = "Pgm";  	// Specifies that we are controlling a program
//	node.program = node.name;					// name of the program to run
	node.typeControl = refreshOpt = "Pgm";		// Will display the program status
	node.labelOn = "Then"					// First button label
	node.labelOff = "Else"					// Second button label
		
	section.list.push(node);
}




// ---------- Set of functions to build the generic variables table ----------


// Builds a "device table" from scratch based on variables only
function tableBuildVarList(xmldata, varList, sectionName, varType)
{
	vars = $(xmldata).find("e"); 

	section = new Object();
	section.location = sectionName; 
	section.list = [];

	vars.each(function() {

		node = new Object();					
	
		node.name = $(this).attr("name");
		node.labelOn = "-1";
		node.labelOff = "+1";
		node.typeControl = "Var";
		node.varControl = 0; // Do not display slider
		node.refreshOpt = "Var";
		node.varType = varType;
		node.varId = $(this).attr("id");
		node.varInc = 1;
		node.varMax = 0;
		
		section.list.push(node);
	});
	
	if (section.list.length>0);  // If there was at least one, include the section.
	{
		section.list.sort(sortBy);
		varList.push(section);
	}
}



// ---------- Function to update a custom table with data coming from /rest/nodes ----------

function tableInitCustomTable(xmldata, deviceList) // Completes a custom device table from the data coming from /rest/nodes
{ 
	var nodes = $(xmldata).find('node');
	var scenes = $(xmldata).find('group');	
	var nodefound;

	// Loop through sections 
	$(deviceList).each(function () {
		var thisloc=this;

		$(thisloc.list).each(function () {
			var thisdev = this;

			listName=thisdev.name;
			listControl=thisdev.control;
			typeControl=thisdev.typeControl;
			
			if (!listControl && typeControl!="Pgm")
		    {
				listControl=listName;
			}
						
			var nameNodeFound=0;
			var controlNodeFound=0;

			// Finds the node, and update the table
			nodes.find("name").filter(function() {return $(this).text() == listName; }).parent().each(function()		
		    {
				nameNodeFound=1
				thisdev.address = $(this).children('address').text();
				thisdev.id = thisdev.address.replace(/\ /g,'_') //converts address into id
				thisdev.devType = $(this).children('type').text();

				if (listName == listControl)   // If No specific control was specified
				{
					controlNodeFound=1
					thisdev.devTypeCtl = thisdev.devType; 
					thisdev.addressControl = thisdev.address;
					adjustNodesExceptions(thisdev); // Make adjustments based on device type			

					if (thisdev.specControls=="stat") // For best performance, we isolate stat processing here.
					{ adjustThermostatExceptions(thisdev, this);	}
				}	
			});
			
			
			if (listName != listControl)  // If a specific control was specified
			{
				nodes.find("name").filter(function() {return $(this).text() == listControl; }).parent().each(function()
			    {
					controlNodeFound=1
					thisdev.devTypeCtl = $(this).children('type').text();
					thisdev.addressControl = thisdev.address;
					adjustNodesExceptions(thisdev); // Make adjustments based on device type

					if (thisdev.specControls=="stat") // For best performance, we isolate stat processing here.
					{ adjustThermostatExceptions(thisdev, this);	}
				});
			}
			
			if (!nameNodeFound) // If device name was not found, see if there is a scene of that name
			{
				scenes.find("name").filter(function() {return $(this).text() == listName; }).parent().each(function() 
			    {
					nameNodeFound=1
					thisdev.address = $(this).children('address').text();
					thisdev.id = thisdev.address.replace(/\ /g,'_') //converts address into id
					thisdev.devType = ""; 
					if (!thisdev.refreshOpt)
					{
						thisdev.refreshOpt = "No"; // Will not try to refresh scene status
					}
				});
			}

			if (!controlNodeFound) // If device control was not found, see if there is a scene of that name
			{
				scenes.find("name").filter(function() {return $(this).text() == listControl; }).parent().each(function() 
			    {
					controlNodeFound=1
					thisdev.addressControl = $(this).children('address').text();
					thisdev.devTypeCtl = ""; 									
				});		
			}																				
		});
	});
} 



// ---------- Functions to update Buttons and variables once /rest/vars/definitions and /rest/programs are loaded.  ----------

// In order to speed up the table display, we display it without waiting this data. At this stage, there are buttons on the page displayed, 
// but no actions are tied to it. These functions updates the buttons so they will work. It also updates the display tag.

// Updates the HTML with the appropriate buttons and display tags for buttons controlling programs
function processPgmButtons(pgmdata, vars1def, vars2def)
{ 
	var programs = $(pgmdata).children('programs').children("program");
	
	// Loop through the devices in the HTML to set the actions for the buttons, and also the corresponding value if this is a var or program status
	$("[buttonPgm]").each(function()
	    {
			var tdcell = $(this)
			var params = tdcell.children().first(); // This finds the div in the cell that contains the parameters to generate the buttons.
			var buttonPgmName = params.attr("buttonpgmname");
			var programId = params.attr("programid");
			var refreshOpt = params.attr("refreshopt");
			var address = params.attr("address");
			var variable = params.attr("variable");
			var varId  = params.attr("varid");
			var varType = params.attr("vartype");
			var labelOn = params.attr("labelon");
			var labelOff = params.attr("labeloff");

			// Set button labels default values
			if (labelOn=="")
			{ 
				labelOn="ON";
			}						

			if (labelOff=="")
			{ 
				labelOff="OFF";
			}						

			// Find the varId and varType if needed
			if (refreshOpt=="Var")
			{ 
				if (varId=="" || varType=="")
				{ 
					var node = $(vars1def).find('[name="' + variable + '"]');
	
					if (node.length>0)
					{ 
						varId = node.attr("id");
						varType = "1";
					}
					else
					{ 
						var node = $(vars2def).find('[name="' + variable + '"]');

						if (node.length>0)
						{ 
							varId = node.attr("id");
							varType = "2";
						}
					}								
					// if varId || varType were not specified explicitly, and we are displaying a variable, we also need to update this variable id in the "display cell"
					// Find the display cell using the variable name, which must then have been specified
					var displaycell = $('[varname="' + variable + '"]');

					if (displaycell.length>0)
					{ 		
						displaycell.attr('vartypeid', varType+varId);
					}	
				}	
			}		

			// Find the programId if needed
			if (programId=="" && pgmdata)
			{ 
				var node = $(pgmdata).find('program:has(name:contains(' + buttonPgmName + '))');
				programId = node.attr("id");

				if (refreshOpt=="All" || refreshOpt=="Pgm" || refreshOpt=="")
				{ 
					// if programId was not specified explicitly, and we have to display the PGM status, we also need to update this id in the "display cell"
					var displaycell = $('[pgmname="' + buttonPgmName + '"]');

					if (displaycell.length>0)
					{ 		
						displaycell.attr('pgmid', programId);
					}	
				}		
			}		
							
			// Generate the buttons
			tdcell.html('<button onclick="pgmRunWithRefresh(\'' + programId + '\', \'runThen\',\'' + refreshOpt + '\',\'' + address + '\',\'' + varId + '\',\'' + varType + '\');">' + labelOn + '</button> ' + 
						'<button onclick="pgmRunWithRefresh(\'' + programId + '\', \'runElse\',\'' + refreshOpt + '\',\'' + address + '\',\'' + varId + '\',\'' + varType + '\');">' + labelOff + '</button>');
	
		});
}


// Updates the HTML with the appropriate buttons and display tags. Used for buttons that directly control variables.
function processVarButtons(vars1def, vars2def)
{ 
	// Loop through the devices in the HTML to set the actions for the buttons, and also the corresponding value if this is a var or program status
	$("[buttonvar]").each(function()
	    {
			var tdcell = $(this)
			var params = tdcell.children().first(); // This finds the div in the cell that contains the parameters to generate the buttons.
			var buttonVarName = params.attr("buttonvarname");
			var refreshOpt = params.attr("refreshopt");
			var variable = params.attr("variable");
			var varId  = params.attr("varid");
			var varType = params.attr("vartype");
			var varInc = params.attr("varinc");
			var varMax = params.attr("varmax");
			var labelOn = params.attr("labelon");
			var labelOff = params.attr("labeloff");
			var devAddress = params.attr("devaddress");

			if (varId=="" || varType=="")
			{ 
				// Set button labels default values
				if (labelOn=="") { labelOn="ON"; }						
				if (labelOff=="") { labelOff="OFF"; }

				var node = $(vars1def).find('[name="' + variable + '"]');

				if (node.length>0)  // If variable was found in vars1def (integer)
				{ 
					varType = "1";
					varId = node.attr("id");
				}
				else // If not, see if it is found in vars2def (state)
				{ 
					var node = $(vars2def).find('[name="' + variable + '"]');

					if (node.length>0)
					{ 
						varType = "2";
						varId = node.attr("id");
					}
				}								

				if (varId!="" && varType!="") // Only proceed if variable name was found.
				{
					// Update this variable id in the "display cell"
					// Find the display cell using the variable name, which must have been specified
					$('[varname="' + variable + '"]').attr('vartypeid', varType+varId);
	
					if (!(varInc>0)) // default value for varInc
					{ 		
						varInc=1;
					}	
	
					var buttonIncrementA = -1*varInc;
					var buttonIncrementB = varInc;
					
					// Generate the buttons
					cellcontent = '<button onclick="varControlWithRefresh(\'' + varType + '\', \'' + varId + '\',\'' + refreshOpt + '\',\'' + buttonIncrementA + '\',\'' + varMax + '\',\'' + devAddress + '\');">' + labelOn + '</button> '
								+ '<button onclick="varControlWithRefresh(\'' + varType + '\', \'' + varId + '\',\'' + refreshOpt + '\',\'' + buttonIncrementB + '\',\'' + varMax + '\',\'' + devAddress + '\');">' + labelOff + '</button>'
					tdcell.html(cellcontent);
				}
			}	
		});
}



// ---------- Functions to init the sliders  ----------
// This does not update the value yet, just the UI.
// This ties the function that is run when the slider moves.


function initDevSliders() // Init sliders for dimmers after /rest/nodes has run and templates has been processed.
{
		 // Init the sliders for dimmers. The existence of this attribute means it's a slider. It is set in the template, based on the device category.
	$("[slid]").slider(   
	{ 
		animate: false, 
		max: 255, 
		stop: function( event, ui ) 
		{ 
			addressControl = ui.handle.parentNode.getAttribute('sladd'); // attribute contains the address
			
			if (ui.value>0)
			{ 
				deviceCmd(addressControl, addressControl, "Yes", 'DON/'+ui.value);
			} 
			else // if value is 0,it means off (a DON/0 will not turn it off)
			{ 
				deviceCmd(addressControl, addressControl, "Yes", 'DOF');
			} 		
		} 
	});

	 // Init the sliders for dimmers working from a scale from 0-100. Implemented to support ZWave Leviton dimmers
	$("[slid100]").slider(   
	{ 
		animate: false, 
		max: 100, 
		stop: function( event, ui ) 
		{ 
			addressControl = ui.handle.parentNode.getAttribute('sladd'); // attribute contains the address
			
			if (ui.value>0)
			{ 
				deviceCmd(addressControl, addressControl, "Yes", 'DON/'+ui.value);
			} 
			else // if value is 0,it means off (a DON/0 will not turn it off)
			{ 
				deviceCmd(addressControl, addressControl, "Yes", 'DOF');
			} 		
		} 
	});
}

function initVarSliders() // Init sliders for variables this runs later, when variables arrives
{ 
	 // Init the sliders for variables. The existence of this attribute means it's a slider for a variable. It is set in the template
	$("[slvartypeid]").each(function(){
		var here = $(this);

		if (here.attr("slvartypeid")=="")   // We need the type and id to setup a slider
			return;
		
		varMax = here.attr("varmax");
		varSliderSnap = here.attr("varSliderSnap");
		
		if (varSliderSnap==0)
		{
			varSliderSnap=1;
		}
		
		if (!(varMax>0)) // default value for varMax.
		{ 		
			varMax=100;
		}	
		
		here.slider(
		{ 
			animate: false, 
			max: varMax, 
			stop: function( event, ui ) 
			{ 
				varType = ui.handle.parentNode.getAttribute('varType'); // Type 1=Integer, 2=State
				varId = ui.handle.parentNode.getAttribute('varId'); 
				refreshOpt = ui.handle.parentNode.getAttribute('refreshOpt');
				devAddress = ui.handle.parentNode.getAttribute('devAddress');

				newvalue = Math.round(ui.value/varSliderSnap)*varSliderSnap;

				varSetValue(varType, varId, newvalue, refreshOpt, devAddress)  
			} 
		});
	});
}



// ---------- Functions to handle devices  ----------


function deviceCmdDON(nodeId, nodeIdRefresh, refreshOpt)   // Turn the device on. If already at On Level or above, go to 100% ON.
{
	var id = nodeIdRefresh.replace(/\ /g,'_')
	var obj = $('[devid=node' + id + 'ST]:first');
	var currentlevel = obj.attr("value"); // This is the current status of the device.
	
	if (currentlevel!=undefined)
	{
		currentlevel = parseInt(currentlevel);
		
		if (currentlevel < 255) // Do nothing if already at 255
		{
			ol = $.jStorage.get("OL" + id); // Gets the ON Level for the device previously stored.
	
			if (currentlevel >= ol && ol>0)  // If we know the OL level, and we are already at OL or above...
			{
				deviceCmd(nodeId, nodeIdRefresh, refreshOpt, 'DON/255'); // Turn on device to 100
			}
			else
			{
				deviceCmd(nodeId, nodeIdRefresh, refreshOpt, 'DON'); // Turn on device to the ON level
			}
		}
	}
	else
	{
		deviceCmd(nodeId, nodeIdRefresh, refreshOpt, 'DON'); // Turn on device to the ON level
	}

}


function deviceCmdDOF(nodeId, nodeIdRefresh, refreshOpt)   // Turn the device off
{
	deviceCmd(nodeId, nodeIdRefresh, refreshOpt, 'DOF');
}


function deviceCmd(nodeId, nodeIdRefresh, refreshOpt, cmd)   // Executes command cmd for device nodeId
{
	var url = "/rest/nodes/" + nodeId + "/cmd/" + cmd
	
	feedbackRequestingURL(url);
	
	var deferred = ajaxCall(url, false);

	if (refreshOpt=="All") //RefreshOpt: All, No, Yes(Default)
	{
		deferred.done(function(data, status, jqXHR){
			if ($(data).children('RestResponse').attr('succeeded') == "true")   //cmd successful
			{
				setTimeout("devicesUpdateStatusAllTables()", wholeTableRefreshDelay); // Because this is a scene, then we will update everything
			}	
			else
			{
				feedbackErrURL(url, "Rest Response not successful");
			}	
		});
	}	
	else if (refreshOpt=="No")
	{
		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message		
	}	
	else  // if refreshOpt=="Yes" or "" (Default refresh option for devices or scenes)
	{
		deferred.done(function(data, status, jqXHR){
			if ($(data).children('RestResponse').attr('succeeded') == "true")   //cmd successful
			{
				scheduleDevRefresh(nodeIdRefresh)
			}
			else
			{
				feedbackErrURL(url, "Rest Response not successful");
			}	
		});
	}

	deferred.fail(function(jqXHR, status, error){
			feedbackErrURL(url, error);
	});
}






function deviceUpdate(address)  // Updates a single node after a command
{
	var url = "/rest/nodes/" + address;

	feedbackRequestingURL(url);

	var deferred = ajaxCall(url, false);

	deferred.done(function(data, status, jqXHR){
		deviceDisplay($(data).children("nodeInfo").children("node"));
		deviceUpdateOL(data);
		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
	});

	deferred.fail(function(jqXHR, status, error){
			feedbackErrURL(url, error);
	});
}



function deviceDisplay(node) // displays the node after a command or on refresh
{
	var address = $(node).children('address').text(); // Will be found if node comes from /rest/nodes

	if (!address)
		address = $(node).attr('id'); // if node data comes from /rest/status, address will be found in the attribute of the node.

	var	id = address.replace(/\ /g,'_') //removes spaces and other problematic characters replaces with '_'
	var propertynode = $(node).children('property[id="ST"]');
	var status = propertynode.attr('formatted');
	var value = propertynode.attr('value');

	// For each properties of device
	$(node).children('property').each(function () {
		var property = $(this).attr('id');	// Thermostat property
		var value = $(this).attr('value');  // Property value 

		if (property=="ST")
		{
			// This is for the issue with the Fanlinc "formatted" attribute which is blank. 
			// When status=="", then (statusPlaceHolder.html() != status) will always be false, value will not be set, On button will not work.
			if (status == "") 
			{
				if (value==0)
				{
					status="Off";
				}					
				else if (value==255)
				{
					status="On";
				}				
				else
				{
					status=Math.round(value*100/255);
				}				
			}				

			var statusClass = (status == "Off")?"off ST":"on ST";
			var type = $(node).children('type').text();
			var cat = parseInt(type.split(".")[0]); 
		
			// Update the text status & the slider
			$('[devid=node' + id + 'ST]').each(function(index, val) {
				var statusPlaceHolder = $(this);
		
				if ((statusPlaceHolder.html() != status.toString()))//If property has changed
				{
					statusPlaceHolder.html(status);//update property
					statusPlaceHolder.attr("class", statusClass);//update class
					statusPlaceHolder.attr("value", value);// Stores the value from 0 to 255
				
					if(cat == 1) // We know there should be a slider -> update it
					{
						$('[slid=slider' + id + ']').each( function(index, val){		
							$(this).slider("option", "value", value);
						});
					}			
					
					// This is for Zwave sliders. See if it can find it.
					$('[slid100=slider' + id + ']').each( function(index, val){		
						$(this).slider("option", "value", value);
					});			
				}			
			});	
		}
		else if ($.inArray(property, ["CLIMD", "CLIFS", "CLISPH", "CLISPC"])!=-1)  // If thermostat property
		{		
			var thermSelector = '[statid=' + id + ']';
			var thermControlSelector = thermSelector + ' [setting='  + property + ']';
						
			if (property=="CLIMD")  // Thermostat mode
			{
				// For each occurence of this thermostat/property in the page, set the spinner property to the approprite value
				$(thermControlSelector).each(function(){			
					$(this).modeSpinner("value", parseInt(value));
				});
			}
			else if (property=="CLIFS")  // Thermostat Fan mode
			{
				// For each occurence of this thermostat/property in the page, set the spinner property to the approprite value
				$(thermControlSelector).each(function(){			
					$(this).fanSpinner("value", parseInt(value));
				});
			}
			else if (property=="CLISPH" || property=="CLISPC")  // Thermostat setpoints
			{
				var multiplier = $(thermSelector).attr("multiplier");

				$(thermControlSelector).each(function(){			
					$(this).spinner("value", parseFloat(value)/multiplier);
				});
			}
		}
	});


	// Update the button status if it finds one.
	var button = '#button' + id;
	$(button + (value>0?"_On":"_Off")).each( function(index, val) {
		$(this).attr('checked', 'checked');  // Updates the Sample Toggle Button
		$(button).buttonset("refresh");
	});		
}



function deviceUpdateOL(xmldata) // Updates the ON Level. This allows to respect the ON Level of the device.
{
	var address = $(xmldata).find('address').text();
	var	id = address.replace(/\ /g,'_')
	var value = $.jStorage.get("OL"+id);

	if(!value)
	{
		value = 255; // Default On Level is 255. if we can't find in the properties. This will happen with non-dimmable devices.
	}
	
	$(xmldata).find('property').each(function()  // If it finds "properties"
    {
		if ($(this).attr('id') == 'OL')
	    {
			value = $(this).attr('value');  // This is the On Level.
		}
	});

	$.jStorage.set("OL"+id, value, { TTL : 604800000 });	// Update the value at this place. Will be set for one week.
}




function deviceGetStatusByAddress(address)  // address = "99 99 99 99" with spaces, no leading zeros.
{
    var statusDeferred = $.Deferred();
    var promise = statusDeferred.promise();
	var url = '/rest/nodes/' + address
	
	feedbackRequestingURL(url);

	var deferred = ajaxCall(url, false);

	deferred.done(function(data, status, jqXHR){
        if (!data) 
		{	
            statusDeferred.reject(status, jqXHR);
        } 
		else 
		{
			value = $(data).find('property').attr('value');
            statusDeferred.resolve(value, data);
        }

		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
	});

	deferred.fail(function(jqXHR, status, error){
            statusDeferred.reject(error, jqXHR);
	});
	
	return promise;	
}


function scheduleDevRefresh(address)
{
	setTimeout("deviceUpdate('" + address + "');", devRefreshDelay);  // Will update the node status after 800ms

	if (devRefreshDelay2)
	{	
		setTimeout("deviceUpdate('" + address + "');", devRefreshDelay2);  // Will update the node status after 800ms
	}

	if (devRefreshDelay3)
	{	
		setTimeout("deviceUpdate('" + address + "');", devRefreshDelay3);  // Will update the node status after 800ms
	}
}


// -------------------- Thermostat related functions ------------------------

var thermostatModeOptions = [ "Off", "Heat", "Cool", "Auto" ];
var thermostatFanOptions = [ "Fan Auto", "Fan On" ];


function extendSpinnerOptions(widgetName, optionsArray)
{
	$.widget("ui." + widgetName, $.ui.spinner, {

	    options: {
	        min: 0,
	        max: optionsArray.length-1
	    },
	    _parse: function(value) {
	        if (typeof value === "string") {
	            return optionsArray.indexOf(value);
	        }
	        return value;
	    },
	    _format: function(value) {
	        return optionsArray[value];
	    },
	});
}


// Inits thermostat spinners
function initStatSpinner()
{
	extendSpinnerOptions("modeSpinner", thermostatModeOptions);
	extendSpinnerOptions("fanSpinner", thermostatFanOptions);

	$('.thermostat [setting=CLIMD]').modeSpinner({ stop: spinChange });
	$('.thermostat [setting=CLIFS]').fanSpinner({ stop: spinChange });

	$('.thermostat').each(function() {
			multiplier = $(this).attr("multiplier");
			clisphOpt = {min: thermHeatMin, max: thermHeatMax, stop: multiplier==2?spinChangeX2:spinChange };
			clispcOpt = {min: thermCoolMin, max: thermCoolMax, stop: multiplier==2?spinChangeX2:spinChange };		
			$(this).find('[setting=CLISPH]').spinner(clisphOpt);
			$(this).find('[setting=CLISPC]').spinner(clispcOpt);
	});
}

var statRequests = {}; // Used to log stat request.


function spinChange(event, ui)
{
	spinChangeMultiplier.call(this, event, ui, 1);
}

// For those thermostat whose value is twice the formatted value (resolution of .5 degrees)
function spinChangeX2(event, ui)
{
	spinChangeMultiplier.call(this, event, ui, 2);
}


function spinChangeMultiplier(event, ui, multiplier)
{
	if (event.type!="mouseleave")   // Somehow, just passing over the buttons triggers the stop event
	{
		var tcontrols = $(this).parent().parent().parent(); 
//		var id = tcontrols.attr("statid");
		var address = tcontrols.attr("statadd");

		var property = $(this).attr("setting");
		var key = address+property; 	// Build a unique address+setting pair
		var value;		
		
		if (property=="CLIMD") { value = $(this).modeSpinner("value"); }
		else if (property=="CLIFS") { value = $(this).fanSpinner("value"); }
		else { value = $(this).spinner("value")*multiplier; }

		if (statRequests[key]!=value) // Skip processing if value is not really changed (Will happen if we hit spinner limits)
		{
			statRequests[key]=value;	
			setTimeout("spinChangeDelayed('" + address + "', '" + property + "', '" + value + "')", thermDelay); 	
		}
	}
}



// After <thermDelay> ms, process the temp change, unless the button was pressed again
function spinChangeDelayed(address, property, value)
{
	var key = address+property;

	lastValueRequested = statRequests[key];

	// We skip temperature changes until the users stops pressing buttons.
	if (lastValueRequested == value)  
	{
		thermostatSet(address, property, value);
	}
}


// address: Address of the thermostat: Ex ZW011
// property: 
//	"CLIMD" - Sets thermostate mode based on value; 0=Off, 1=Heat,2=Cool, 3=Auto
// 	"CLISPH" - Sets heat setpoint to value
//  "CLISPC" - Sets cool setpoint to value
//	"CLIFS" - Sets thermostate fan mode base on value; 0=Auto, 1=On
// refreshOpt
//  "No": Do not refresh
//  "Yes": Refresh temp and setpoints (default)	

function thermostatSet(address, property, value)
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var url = "/rest/nodes/" + address + "/cmd/" + property + "/" +value;

	feedbackRequestingURL(url);
	
	var ajaxCallDeferred = ajaxCall(url, true);

	ajaxCallDeferred.done(function(data, status, jqXHR){

        if (!data)
		{	
            deferred.reject(status, jqXHR);
        } 
		else
		{
			setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
			setTimeout("deviceUpdate('" + address + "');", thermRefreshDelay); // Normally, this delay should be longer than noerrFeedbackDelay
			deferred.resolve(value, data);
	    }
	});
	
	ajaxCallDeferred.fail(function(jqXHR, status, error){
		feedbackErrURL(url, error);
		deferred.reject(error, jqXHR);
	});

	return promise; 
}




// ---------- Functions to handle Programs ----------


function pgmRun(pgmId, cmd, varId, varType)   // cmd: run|runThen|runElse|stop|enable|disable|enableRunAtStartup|disableRunAtStartup 
{
	var url = "/rest/programs/" + pgmId + "/" + cmd;

	feedbackRequestingURL(url);

	var deferred = ajaxCall(url, true); // For some reason, cache has to be true.
	
	deferred.done(function(data, status, jqXHR){
		feedback('Program run ' + url);
		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
	});

	deferred.fail(function(jqXHR, status, error){
			feedbackErrURL(url, error);
	});
	// To be enhanced with a return promise.
}

// Program run from the devices table. Allows to run a pgm and then update the devices.
function pgmRunWithRefresh(pgmId, cmd, refreshOpt, nodeRefresh, varId, varType)   // cmd: run|runThen|runElse|stop|enable|disable|enableRunAtStartup|disableRunAtStartup 
{
	var url = "/rest/programs/" + pgmId + "/" + cmd;
	feedbackRequestingURL(url);

	var deferred = ajaxCall(url, true); // For some reason, cache has to be true.

	if (refreshOpt=="All") //RefreshOpt: All, No, Yes(Default)
	{
		deferred.done(function(data, status, jqXHR){
			if ($(data).children('RestResponse').attr('succeeded') == "true")   //cmd successful
			{
				setTimeout("devicesUpdateStatusAllTables()", wholeTableRefreshDelay); // Because this is a scene, then we will update everything
			}	
			else
			{
				feedbackErrURL(url, "Rest Response not successful");
			}	
		});
	}	
	else if (refreshOpt=="Yes")
	{
		deferred.done(function(data, status, jqXHR){
			if ($(data).children('RestResponse').attr('succeeded') == "true")   //cmd successful
			{
				scheduleDevRefresh(nodeRefresh);
			}
			else
			{
				feedbackErrURL(url, "Rest Response not successful"); 
			}	
		});
	}
	else if (refreshOpt=="Var")
	{
		deferred.done(function(data, status, jqXHR){
			if ($(data).children('RestResponse').attr('succeeded') == "true")   //cmd successful
			{
				setTimeout('varUpdateStatus("' + varId + '","' + varType + '");', varRefreshDelay);  // Will update the node status
			}
			else
			{
				feedbackErrURL(url, "RestResponse not successful");
			}	
		});
	}	
	else if (refreshOpt=="No")
	{
		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
	}	
	else // default refresh option for a program is "Pgm"
	{
		deferred.done(function(data, status, jqXHR){
			if ($(data).children('RestResponse').attr('succeeded') == "true")   //cmd successful
			{
				setTimeout('pgmUpdateStatus("' + pgmId + '");', pgmRefreshDelay);  // Will update the node status
			}
			else
			{
				feedbackErrURL(url, "Rest Response not successful");
			}	
		});
	}	

	deferred.fail(function(jqXHR, status, error){
			feedbackErrURL(url, error);
	});
}


function pgmUpdateStatus(id) // displays the program status after a refresh
{
	var defer = pgmGetStatus(id);

	defer.done(function(status){
		pgmDisplayStatus($('[pgmid="' + id + '"]'), status);
		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
	});		
}
			
function pgmDisplayStatus(statusPlaceHolder, status) // displays the program status after a refresh
{
	var value;
	var statusClass;
	
	if (status)
	{
		value = "On";
		statusClass = "on ST";
	}
	else
	{
		value = "Off";
		statusClass = "off ST";
	}
	
	$(statusPlaceHolder).html(value);//update property
	$(statusPlaceHolder).attr("class", statusClass);//update class
}


function pgmGetStatus(pgmId)
{
    var deferred = $.Deferred();
    var promise = deferred.promise();
	var url = "/rest/programs/" + pgmId;

	var ajaxCallDeferred = ajaxCall(url, true);

	ajaxCallDeferred.done(function(data, status, jqXHR){
        if (!data)
		{	
            deferred.reject(status, jqXHR);
        } 
		else
		{
			var stateStr = $(data).find('program').attr('status');
			var state = (stateStr == "true")?1:0;
			deferred.resolve(state, data);
        }
	});
	
	ajaxCallDeferred.fail(function(jqXHR, status, error){
		feedbackErrURL(url, error);
		deferred.reject(error, jqXHR);
	});

	return promise; 
}


// ---------- Functions to handle Variables ----------


function varControlWithRefresh(varType, varId, refreshOpt, varInc, varMax, devAddress)   
{
	var actualValue = $('[vartypeid=' + varType + varId + ']').html(); // Picks up the actual value on the screen
	var newValue = parseInt(actualValue) + parseInt(varInc);

	if (newValue > varMax && varMax!=0) // varMax==0 means no limit
	{
		newValue=varMax;
    };

	if (newValue < 0)
	{
		newValue=0;
    };
		
	varSetValue(varType, varId, newValue, refreshOpt, devAddress)  // Type 1=Integer, 2=State	
}




function varGetValue(type, id)  // Type 1=Integer, 2=State
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var url = "/rest/vars/get/" + type + "/" + id;
	
	var ajaxCallDeferred = ajaxCall(url, true);

	ajaxCallDeferred.done(function(data, status, jqXHR){
        if (!data)
		{	
            deferred.reject(status, jqXHR);
        } 
		else
		{
			var state = $(data).find('val').text();
			deferred.resolve(state, data);
        }
	});
	
	ajaxCallDeferred.fail(function(jqXHR, status, error){
		feedbackErrURL(url, error);
		deferred.reject(error, jqXHR);
	});

	return promise; 
}


function varSetValue(type, id, value, refreshOpt, devAddress)  // Type 1=Integer, 2=State
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var url = "/rest/vars/set/" + type + "/" + id + "/" + value;

	feedbackRequestingURL(url);

	var ajaxCallDeferred = ajaxCall(url, true);

	ajaxCallDeferred.done(function(data, status, jqXHR){

        if (!data)
		{	
            deferred.reject(status, jqXHR);
        } 
		else
		{
			if (refreshOpt=="All") //RefreshOpt: All, No, Var(Default)
			{
				setTimeout("devicesUpdateStatusAllTables()", wholeTableRefreshDelay); // Because this is a scene, then we will update everything
			}	
			if (refreshOpt=="Yes") //RefreshOpt: All, No, Var(Default)
			{
				setTimeout('varUpdateStatus("' + id + '","' + type + '");', varRefreshDelay);  // We need it to keep track of the var current value
				setTimeout("deviceUpdate('" + devAddress + "');", varRefreshDelay+noerrFeedbackDelay+200);  // Will then update the node status
			}
			else if (refreshOpt=="No")
			{
				setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
			}	
			else  // Default refreshOpt for a variable is "Var"
			{
				setTimeout('varUpdateStatus("' + id + '","' + type + '");', varRefreshDelay);  // Will update the node status
			}	

			deferred.resolve(value, data);
	    }
	});
	
	ajaxCallDeferred.fail(function(jqXHR, status, error){
		feedbackErrURL(url, error);
		deferred.reject(error, jqXHR);
	});

	return promise; 
}




function varUpdateStatus(id, type) // displays the var status after a refresh
{
	var defer = varGetStatus(id, type);

	defer.done(function(value){
		$('[vartypeid=' + type + id + ']').html(value);

		slider = $('[slvartypeid="'+ type + id +'"]');

		if (slider.hasClass("ui-slider")) // Check if slider has been initialized
		{
			slider.slider("option", "value", parseInt(value)); // Set the corresponding slider
		}

		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
	});		
}

function varGetStatus(varId, varType)
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var url = "/rest/vars/get/" + varType + "/" + varId;

	var ajaxCallDeferred = ajaxCall(url, true);

	ajaxCallDeferred.done(function(data, status, jqXHR){
        if (!data)
		{	
            deferred.reject(status, jqXHR);
        } 
		else
		{
			var value = $(data).find('val').text(); 
			
			deferred.resolve(value, data);
        }
	});
	
	ajaxCallDeferred.fail(function(jqXHR, status, error){
		feedbackErrURL(url, error);
		deferred.reject(error, jqXHR);
	});

	return promise; 
}

function varFindValue(varsdata, id)  // Finds value of variable id in varsdata (from /rest/vars/get/?)
{
	return parseInt($(varsdata).find('[id="' + id + '"]').children("val").text())
}




// ---------- Weather information ------------------

function getWeather() 
{
	var url = "/rest/climate"

	feedbackRequestingURL(url)

	var deferredWeather = ajaxCall(url, true); // Reads the list of nodes

	deferredWeather.done(function(confdata, status, jqXHR){

		var	coverage=0; 
		var	intensity=0; 		
		var	weatherCondition=0; 		

		var	coverage24Hr=0; 
		var	intensity24Hr=0; 		
		var	weatherCondition24Hr=0; 		
		
		var	coverageTomorrow=0; 
		var	intensityTomorrow=0; 		
		var	weatherConditionTomorrow=0; 		

		lastUpdated = $(confdata).find("climate").attr("lastUpdatedTS");
		$("#WeatherLastUdated").html(lastUpdated);
		
		$(confdata).find("climate").children().each(function() {
			var tagName = $(this).get(0).tagName;
			var id = "#" + tagName; // Gets the name of the DOM element, builds an ID from it. 
			$(id).html($(this).text()); // If it finds the weather id, display the value there. 

			switch (tagName) {
				case "Coverage": 			coverage = parseInt($(this).text()); break;
				case "Intensity": 			intensity = parseInt($(this).text()); break;
				case "Weather_Condition": 	weatherCondition = parseInt($(this).text()); break;
				case "Cloud_Condition": 	
					var cloudCondition = parseInt($(this).text()); 
					id += "_TEXT";

					if (cloudCondition && cloudCondition < ClimCloudConditions.length)
						$(id).html(ClimCloudConditions[cloudCondition]).parent().removeClass("hidden");
					break;

				case "Forecast_Coverage": 			coverage24Hr = parseInt($(this).text()); break;
				case "Forecast_Intensity": 			intensity24Hr = parseInt($(this).text()); break;
				case "Forecast_Weather_Condition": 	weatherCondition24Hr = parseInt($(this).text()); break;
				case "Forecast_Cloud_Condition": 	
					var cloudCondition24Hr = parseInt($(this).text()); 
					id += "_TEXT";

					if (cloudCondition24Hr && cloudCondition24Hr < ClimCloudConditions.length)
						$(id).html(ClimCloudConditions[cloudCondition24Hr]).parent().removeClass("hidden");

					break;

				case "Coverage_Tomorrow": 			coverageTomorrow = parseInt($(this).text()); break;
				case "Intensity_Tomorrow": 			intensityTomorrow = parseInt($(this).text()); break;
				case "Weather_Condition_Tomorrow": 	weatherConditionTomorrow = parseInt($(this).text()); break;
				case "Cloud_Condition_Tomorrow": 	
					var cloudConditionTomorrow = parseInt($(this).text()); 
					id += "_TEXT";

					if (cloudConditionTomorrow && cloudConditionTomorrow < ClimCloudConditions.length)
						$(id).html(ClimCloudConditions[cloudConditionTomorrow]).parent().removeClass("hidden");

					break;
			}
		});
		
		if (coverage || intensity || weatherCondition)
		{
			if (coverage<ClimCoverage.length && intensity<ClimIntensity.length  && weatherCondition<ClimWeatherConditions.length)
			{
				var summary = ClimCoverage[coverage] + " " + ClimIntensity[intensity] + " " + ClimWeatherConditions[weatherCondition];			
				$("#Summary_TEXT").html(summary).parent().removeClass("hidden");
			}
		}

		if (coverage24Hr || intensity24Hr || weatherCondition24Hr)
		{
			if (coverage24Hr<ClimCoverage.length && intensity24Hr<ClimIntensity.length  && weatherCondition24Hr<ClimWeatherConditions.length)
			{
				var summary = ClimCoverage[coverage24Hr] + " " + ClimIntensity[intensity24Hr] + " " + ClimWeatherConditions[weatherCondition24Hr];			
				$("#Summary_24HR_TEXT").html(summary).parent().removeClass("hidden");
			}
		}

		if (coverageTomorrow || intensityTomorrow || weatherConditionTomorrow)
		{
			if (coverageTomorrow<ClimCoverage.length && intensityTomorrow<ClimIntensity.length  && weatherConditionTomorrow<ClimWeatherConditions.length)
			{
				var summary = ClimCoverage[coverageTomorrow] + " " + ClimIntensity[intensityTomorrow] + " " + ClimWeatherConditions[weatherConditionTomorrow];			
				$("#Summary_Tomorrow_TEXT").html(summary).parent().removeClass("hidden");
			}
		}

		// Enable the display of the weather once data is received
		$("#weather").removeClass("hidden");

		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message		
	});

	deferredWeather.fail(function(jqXHR, status, error){
		feedbackErrURL(url, error);
	});	
	
	$("button").blur(); // remove focus from all buttons, including refresh button.
}




// ---------- Functions to handle refresh ----------

// Check if there is more than 20 program status to update. It takes > 20 pgms to justify a /rest/programs/?subfolders=true
// pgmdata is optionnal. We use it at init time since we already have it.

function pgmUpdateAllStatus(pgmdata)  // If we can supply pgmdata, the screen update is faster
{
	var url = "/rest/programs/?subfolders=true"
	pgmTags = $("[pgmid]");
	
	if (!pgmdata && pgmTags.length>20)  // If we don't have the data, and need more than 20 status, get them all
	{
		var deferredPgm = ajaxCall(url, true); // Reads the list of Pgms		

		deferredPgm.done(function(pgmdata, status, jqXHR){
			pgmUpdateAllStatus(pgmdata);  
		});

		deferredPgm.fail(function(jqXHR, status, error){
			feedbackErrURL(url, error);
		});	

	}
	else
	{
		pgmTags.each(function(){
			var node = $(this)
			var pgmId = node.attr('pgmid');
	
			if (!pgmdata) // If we don't have program data, fetch it one by one
		    {
				var defer = pgmGetStatus(pgmId);
				defer.done(function(status){
					pgmDisplayStatus(node, status);
					setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message 	
				});
			}	
			else
		    {
				var status = $(pgmdata).find('[id="' + pgmId + '"]').attr('status');		
				pgmDisplayStatus(node, status=="true"?true:false);
			}	
		});	

		$("button").blur(); // remove focus from all buttons, including refresh button.
	}			
}


function varUpdateAllStatus(vardata1, vardata2)  
{
	var url1 = "/rest/vars/get/1";
	var url2 = "/rest/vars/get/2";
	varTags = $("[vartypeid]");
	
	if (!vardata1 && !vardata2) // If we don't have one, go fetch first
	{
		var deferredVars1 = ajaxCall(url1, true); // Reads the list of variables of type integer	
		var deferredVars2 = ajaxCall(url2, true); // Reads the list of variables of type state		

		$.when(deferredVars1, deferredVars2).done(function(vars1Args, vars2Args){
			varUpdateAllStatus(vars1Args[0], vars2Args[0]); 
		});			

		deferredVars1.fail(function(jqXHR, status, error){
			feedbackErrURL(url1, error);
		});	

		deferredVars2.fail(function(jqXHR, status, error){
			feedbackErrURL(url2, error);
		});	
	}
	else
	{
		varTags.each(function(){
			var node = $(this)
			var typeid = node.attr('vartypeid');
			var type = typeid.substr(0, 1);
			var id = typeid.substr(1);
			var value = 0;
				
			if (type==1)
			{
				$(vardata1).find("[id=" + id + "]").each(function() {
					value = $(this).children("val").text();
				});
			}
			else
			{
				$(vardata2).find("[id=" + id + "]").each(function() {
					value = $(this).children("val").text();
				});
				
			}
				
			$(node).html(value);
			
			slider = $('[slvartypeid="'+ typeid +'"]');

			if (slider.hasClass("ui-slider")) // Check if slider has been initialized
			{
				slider.slider("option", "value", parseInt(value)); // Set the corresponding slider
			}
		});	

		$("button").blur(); // remove focus from all buttons, including refresh button.
	}
}


// main function to update all devices status on all tables. Called from the "Status refresh" button.
function devicesUpdateStatusAllTables() 
{ 
	// Fetching of device status is done once for all of them
	var defer = devicesFetchStatus();

	defer.done(function(data){
		// Update all status wherever it is (not dependant on the table)
		$(data).find('node').each(function() { 
			deviceDisplay(this);
		});

//		pgmUpdateAllStatus();  // Update programs status
//		varUpdateAllStatus();  // Update Vars
	});
	
	$("button").blur(); // remove focus from all buttons, including refresh button.
}



// Used by devicesUpdateStatusAllTables()
function devicesFetchStatus()  // Reads the status of all devices and returns a promise
{
    var statusDeferred = $.Deferred();
    var promise = statusDeferred.promise();

	var url = "/rest/status" // Faster than /rest/nodes, and has all the data we need.

	feedbackRequestingURL(url);

	var deferred = ajaxCall(url, false);

	deferred.done(function(data, status, jqXHR){
        if (!data) 
		{	
            statusDeferred.reject(status, jqXHR);
        } 
		else 
		{
            statusDeferred.resolve(data);
        }

		setTimeout("feedback('');", noerrFeedbackDelay); // Resets feedback message
	});

	deferred.fail(function(jqXHR, status, error){
			feedbackErrURL(url, error);
            statusDeferred.reject(error, jqXHR);
	});
	
	return promise;	
}



// ---------- Functions to handle automatic refresh ----------


function startAutomaticDevRefresh(delayedStart)
{   
	if (!automaticDevRefreshActive && automaticDevRefreshDelay) // Do not activate if delay is set to 0, or if already active;
	{
		automaticDevRefreshActive=1	

		if (delayedStart)
		{
			automaticDevRefreshTimeoutTimer = setTimeout("automaticDevRefresh()", delayedStart);	
		}
		else
		{
			automaticDevRefresh(); // Start now
		}
	}
}

function stopAutomaticDevRefresh()
{   
	if (automaticDevRefreshTimeoutTimer)
	{
		clearTimeout(automaticDevRefreshTimeoutTimer); // Stops the current active refresh timer.
		automaticDevRefreshTimeoutTimer=0;
	}
	automaticDevRefreshActive=0;	
}


function automaticDevRefresh()
{   
	devicesUpdateStatusAllTables();
	automaticDevRefreshTimeoutTimer = setTimeout("automaticDevRefresh()", automaticDevRefreshDelay);		
}



// ---------- Lower level functions ----------

function ajaxCall(url, cache) // Calls a rest service. Cache can be true or false.
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var jqXHR = $.ajax(
	{
	    type: "GET",
	    url: url, 
	    dataType: "xml",
		async: true,
		cache: cache
	});
	
    jqXHR.done(function(data, status, jqXHR) {
        if (!data) {	
            deferred.reject(jqXHR, 'error');
        } else {
            deferred.resolve(data, status, jqXHR);
        }
    });
	
    jqXHR.fail(function(jqXHR, status, error) {
	        deferred.reject(jqXHR, status, error);
    });
	
	return promise;
}



function ajaxJsonCall(url, cache) // Calls a rest service. Cache can be true or false. Used for Camera configs, and voip.ms interface
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var jqXHR = $.ajax(
	{
	    type: "GET",
	    url: url, 
	    dataType: "json",
		async: true,
		cache: cache
	});
	
    jqXHR.done(function(data, status, jqXHR) {
        if (!data) {	
            deferred.reject(jqXHR, 'error');
        } else {
            deferred.resolve(data, status, jqXHR);
        }
    });
	
    jqXHR.fail(function(jqXHR, status, error) {
	        deferred.reject(jqXHR, status, error);
    });
	
	return promise;
}


var sortOrder = "name";

function sortBy(a,b)//Sorts list by column specified by sortOrder variable
{
	if (a.folder == true && !b.folder){
		return -1;
	}
	else if (!a.folder && b.folder == true){
		return 1;
	}
	else if (a.cat == 5 && b.cat != 5){
		return -1;
	}
	else if (a.cat != 5 && b.cat == 5){
		return 1;
	}
	else{
		return ((a[sortOrder] > b[sortOrder])-(a[sortOrder] < b[sortOrder]));
	}
}


function processTemplate(placeHolder, data, template) // Process the deviceTemplate based on the template, at placeHolder
{ 
	$(placeHolder).setTemplateElement(template);
	$(placeHolder).processTemplate(data); // Displays the table using the template
}


function feedbackRequestingURL(url, selector)
{
	feedback('Requesting ' + url, selector); // Will leave the error on screen.
}


function feedbackErrURL(url, errorMsg, selector)
{
	feedback('Error accessing ' + url + ': '+ errorMsg, selector); // Will leave the error on screen.
}


function feedback(text, selector) // Displays a status at the top of page
{
	if (!selector)
	{
		selector = "[feedback]"; // Default feedback placeholder: any tag with the attribute feedback.
	}

	if (!text || text == "")
		text = "<br>";
	
	$(selector).html(text);
}


function webAdminUI(version)  // if version is supplied, use it instead of the global firmwareVersion defined
{
	if(version)
	{
		firmwareVersion = version;
	}
	
	window.open('http://isy.universal-devices.com/994i/' + firmwareVersion +'/admin.jnlp');
}


function isIE()
{
	return Object.hasOwnProperty.call(window, "ActiveXObject");
}