var camTypes = {
  "foscam":{name:'Foscam', models:{
    '1':{name:'Foscam (Generic)', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'},
    '2':{name:'Foscam FI89xx', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'},
    '4':{name:'Foscam FI98xx (H.264)', snapshot:'/cgi-bin/CGIProxy.fcgi?cmd=snapPicture2&usr=<user>&pwd=<pass>'}
  }},"smarthome":{name:'Smarthome', models:{
    '1':{name:'Smarthome', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'},
    '2':{name:'Smarthome Outdoor', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'}
  }},"axis":{name:'Axis', models:{
    '1':{name:'Axis (Generic)', snapshot:'/axis-cgi/jpg/image.cgi'}      
  }},"panasonic":{name:'Panasonic', models:{
    '1':{name:'Panasonic (Generic)', snapshot:'/SnapshotJPEG'},
    '2':{name:'Panasonic BL-Cxx', snapshot:'/SnapshotJPEG'}    
  }},"MJPGstreamer":{name:'MJPG-streamer', models:{
    '1':{name:'MJPG-Streamer', snapshot:'/?action=snapshot'}
  }}
};

var b = 0;
//go through camTypes and make a list of brands then model for each brand into an array so it can be sorted
camTypes.list = makeList;
for (var brand in camTypes)
{
    if (camTypes[brand].models)
    {   
        camTypes[brand].models.list = makeList;
    }
}