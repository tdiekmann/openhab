var camTypes = 
{
  "foscam":{name:'Foscam', models:{
    '1':{name:'Foscam (Generic)', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'},
    '2':{name:'Foscam FI89xx44', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'},
    '4':{name:'Foscam FI98xx (H.264)', snapshot:'/cgi-bin/CGIProxy.fcgi?cmd=snapPicture2&usr=<user>&pwd=<pass>'}
  }},"smarthome":{name:'Smarthome', models:{
    '1':{name:'Smarthome', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'},
    '2':{name:'Smarthome Outdoor', snapshot:'/snapshot.cgi?user=<user>&pwd=<pass>'}
  }},"axis":{name:'Axis', models:{
    '1':{name:'Axis (Generic)', snapshot:'/axis-cgi/jpg/image.cgi'}      
  }},"panasonic":{name:'Panasonic', models:{
    '2':{name:'Panasonic (Generic)', snapshot:'/SnapshotJPEG'},
    '3':{name:'Panasonic BL-Cxx', snapshot:'/SnapshotJPEG'}    
  }},"MJPGstreamer":{name:'MJPG-streamer', models:{
    '1':{name:'MJPG-Streamer', snapshot:'/?action=snapshot'}
  }}
};


function initCams()
{
    var deferred = loadCustomConfig('camsconf.jsn');

	deferred.done(function(data){
		camsConfig=data;
		displayCamPage("#camsPlaceholder", camsConfig, "displayCam", "camImg")
	});
	
	deferred.fail(function(jqXHR, status, error){
		camsConfig = {}
		displayCamPage("#camsPlaceholder", camsConfig, "displayCam", "camImg")
	});	


	camTypes.list = makeList;
	for (var brand in camTypes)
	{
	    if (camTypes[brand].models)
	    {   
	        camTypes[brand].models.list = makeList;
	    }
	}
}

function stopCams()
{
	$("#camImg").attr("activeid", ""); // Currently the UI only support one hardcoded cam image placeholder. By removing it, it stops the process.
}


function displayCamPage(placeHolder, data, template, imgID) // Process the camera display template 
{ 
	$(placeHolder).setTemplateElement(template);
	$(placeHolder).setParam("imgID", imgID);
	$(placeHolder).processTemplate(data); // Displays the table using the template
}


function newCam()
{
	processTemplate("#camsPlaceholder", camTypes, "editCam")
}


function editCam()
{
	var currentCam;
	var id = $("#camSelect").val();  //get id from the form

	camsConfig.lastViewed=id; // When we return to viewing, this will come back to the same cam.

	processTemplate("#camsPlaceholder", camTypes, "editCam")

	currentCam = camsConfig.cams[searchId(camsConfig.cams, id)];  // Finds the cam config for the selected cam.

	if (currentCam)
	{
		for (var key in currentCam) // Fills the input fields
		{
			$("[name='" + key + "']").val(currentCam[key]);
		}

		$("#camTitle").html('Edit Camera:');	//change title
		$(".delBtn").removeClass('hidden');	// show delete button
	}
	
	camSelectBrand(currentCam.Brand); 	// Activates the appropriate model field
}


function deleteCam()
{
	var id = $("[name='Id']").val(); // Currently edited ID.
	var name = $("[name='Name']").val(); // Currently edited Cam name.

	var index = searchId(camsConfig.cams, id);  // Finds the current cam config for the selected cam.

	if (confirm('Delete Cam:'+ name+ '?'))
	{
		camsConfig.cams.splice(index, 1);
	}
	
	saveCustomConfig('camsconf.jsn', camsConfig);

	displayCamPage("#camsPlaceholder", camsConfig, "displayCam", "camImg")
}


function cancelEditCam()
{
	displayCamPage("#camsPlaceholder", camsConfig, "displayCam", "camImg")
}


function saveCam() 
{
	var id = $("[name='Id']").val(); // Currently edited ID.

	if (!id || id == "") //if we are adding a new cam, assign it a new id.
	{
		if (camsConfig.lastId)
		{
			id = parseInt(camsConfig.lastId, 10) + 1;
		}
		else 
		{
			id = 1; 	//if we don't have a last id start at 1
		}
	
		camsConfig.lastId = id;
		camsConfig.lastViewed = id;

		var cam = new Object();
		cam.Id=id.toString();

		if (!camsConfig.cams) // If this is the first cam to be added, create the array first.
		{
			camsConfig.cams = [];
		}
		camsConfig.cams.push(cam);   // Adds a new cam config item, with just the ID in it. The rest of the save will pickup the fields and update it.
	}

	var index = searchId(camsConfig.cams, id);  // Finds the current cam config for the selected cam.

	currentCam = camsConfig.cams[index];
	
	//parse form elements in the edit cam section and update the config
	$('.editCam .parse').each(function(){
		if (this.value)
		{
			currentCam[this.name] = this.value;
		}
		else
		{
			currentCam[this.name] = ''; //if we are missing a value but the element was there with a parse class it was blank set the setting to nothing
		}
	});

	saveCustomConfig('camsconf.jsn', camsConfig);

	displayCamPage("#camsPlaceholder", camsConfig, "displayCam", "camImg")
}




function searchId(source, id) // Searches object with "Id"==id, returns index in source array
{
    var index;
    var entry;

    for (index = 0; index < source.length; ++index) {
        entry = source[index];
        if (entry && entry.Id && entry.Id.indexOf(id) !== -1) {
            return index;
        }
    }
}


function loadCustomConfig(configFile)
{
    var deferred = $.Deferred();
    var promise = deferred.promise();

	var ajaxDeferred = ajaxJsonCall(camConfigLocation + configFile, true);

	ajaxDeferred.done(function(data, status, jqXHR){
        if (status=="success")
		{		
			deferred.resolve(data);
        }
		else
		{	
            deferred.reject(status, jqXHR);
        } 
	});
	
	ajaxDeferred.fail(function(jqXHR, status, error){
		deferred.reject(error, jqXHR);
	});

	return promise; 
}

function saveCustomConfig(configFile, data)
{
	var completeUrl = camConfigLocationUpload + configFile + "?load=N";
	feedback('Saving ... ' + completeUrl);

	data.version=1; // Sets a config file version. Will be used on later releases.

	$.ajax({
		type: "POST",
		timeout: 60000,
		url: completeUrl,
		data : JSON.stringify(data),
		contentType : 'application/json',

		error: function(HttpRequest, textStatus, errorThrown){
			feedback(textStatus + ',  saving: ' + completeUrl, "error");
          },

		success: function(data) { 
			setTimeout("feedback('');", 800); // Resets feedback message after 800ms			
		}
	});
}




function makeList()//takes an object of objects and makes an array list from it
{//assumes the key of the sub objects is it's id and copies it in for easier access
    var list = new Array();
    var c = 0;
    for (var object in this)
    {
        if(typeof(this[object]) == 'object')//make sure item is object
        {
            list[c] = this[object];
            list[c].id = object;//copy id into object for easy access
        }
        c++;
    }
    return list;
}


function camSelectBrand(brand)
{
	if (brand == 'raw')
	{
		//show and parse raw camera options hide normal camera options
		$(".cam-normal").addClass('hidden');
		$(".cam-raw").removeClass('hidden');
		$(".cam-raw input").addClass('parse');
	}
	else//show&parse normal camera config, hide and do-not parse raw config
	{
		$(".cam-normal").removeClass('hidden');
		$(".cam-normal input").addClass('parse');
		$(".cam-raw").addClass('hidden');
		$(".cam-raw input").removeClass('parse');
		//show and parse the select box for that brand hide remove parse for the others
		$('.camModel').addClass('hidden').removeClass('parse');
		$('.camModel.cb-'+brand).removeClass('hidden').addClass('parse');
	}
}

function addNoCacheParam(url)
{
	if(url.indexOf("?") >= 0)    // Time will be added to the URL at Run time, to prevent caching
	{
		url += "&noCache=";
	}
	else
	{
		url += "?noCache=";
	}
	
	return url;
}


function displayCam(id, target)  // Initiates the display of the camera image. 
{
	var camUrlSet=[]; // An array of 2 URLs, one local, one remote

	if (!camsConfig.cams)  // If there is no config loaded. Will happen the first time.
	{
		return;
	}

	var index = searchId(camsConfig.cams, id);  	// Finds the current cam config for the selected cam.

	if (camsConfig.cams[index].Brand == 'raw')		//if camera brand is raw grab the snapshot url start display
	{
		var url = camsConfig.cams[index].Url;
		var altUrl = camsConfig.cams[index].AltUrl;

		if (url) 	// Only add to the array if url was provided.
		{
			if (url.indexOf('http') < 0)		//if http:// is missing add it
			{
				url = 'http://' + url;
			}
	
			url = addNoCacheParam(url);
			camUrlSet.push(url);
		}
		
		if (altUrl) 	// Only add to the array if Alternate URL was provided.
		{
			if (altUrl.indexOf('http') < 0)		//if http:// is missing add it
			{
				altUrl = 'http://' + altUrl;
			}
			altUrl = addNoCacheParam(altUrl);
			camUrlSet.push(altUrl);	
		}
	}
	else  //use brand and model to get cameraType info and assemble the url
	{
		if (camsConfig.cams[index].Brand!="null")  
		{
			var model = camTypes[camsConfig.cams[index].Brand].models[camsConfig.cams[index].Model];
	
			if (model != undefined)
			{
				var camUrl="http://"; // Base URL for both Primary and Alternate URL
				var camUrlPrimary="";
				var camUrlAlt="";
				
				var ip = camsConfig.cams[index].Ip;
				var port = camsConfig.cams[index].Port;
				var altIp = camsConfig.cams[index].AltIp;
				var altPort = camsConfig.cams[index].AltPort;
				var user = camsConfig.cams[index].User
				var password = camsConfig.cams[index].Pass
		
				//if the snapshot url does not have a user and password in it add it after the http:// instead (Except for IE, which do not support it)
				if (model.snapshot.indexOf('<user>') < 0 && !isIE())
				{
					if (user)
					{
						camUrl += user;

						if (password)
						{	
							camUrl +=  ":" + password;
						}

						camUrl += "@";
					}
				}
				
				if (port) //if given add port to ip
				{
					ip += ":" + port;
				}

				camUrlPrimary = camUrl + ip + model.snapshot;				
				camUrlPrimary = camUrlPrimary.replace(/<user>/g, user);
				camUrlPrimary = camUrlPrimary.replace(/<pass>/g, password);
				camUrlPrimary = addNoCacheParam(camUrlPrimary);
				camUrlSet.push(camUrlPrimary);
				
				if (altIp)
				{
					if (altPort) //if given add port to ip
					{
						altIp += ":" + altPort;
					}

					camUrlAlt = camUrl + altIp + model.snapshot;				
					camUrlAlt = camUrlAlt.replace(/<user>/g, user);
					camUrlAlt = camUrlAlt.replace(/<pass>/g, password);
					camUrlAlt = addNoCacheParam(camUrlAlt);			
					camUrlSet.push(camUrlAlt);
				}
			}
		}
	}

	if (camUrlSet.length)  // camUrlSet array length will be 0 if brand/model was not selected, or custom URL empty
	{
		finished = new Array();
	
		//start image updating process
		$(target).empty(); //clear old images
		$(target).attr("activeid", id); // Cam becomes active

		if (camUrlSet.length>1) // If there are 2 host specified, it is worth checking if the first one is online
		{
			var camImgTimeout=2000; 
			var index=0;

			senseIP(hostname(camUrlSet[0]), camImgTimeout).done(function(ping){
				if (ping > camImgTimeout)
				{
					index = 1;	//If first URL not responding, use alternate URL.
				}
				
				loadCamImage(id, camUrlSet, index, target);
			});
	
		}
		else
		{
			loadCamImage(id, camUrlSet, 0, target);
		}
	
		//update select box if needed (if id specified in params != id in select box). Can be different at init time.
		if ($('.camSelect').val() != id)
			{$('.camSelect').val(id);}
	}
	else  // If we could not generate an appropriate cam URL, disactivate 
	{	
		$(target).empty(); //clear old images
		$(target).attr("activeid", ""); // By default, cam is not active.
	}
}
		
// urlset is an array of 2 Urls, local and alternate Url
// currentUrlIndex is the current Url used in the array
function loadCamImage(id, urlSet, currentUrlIndex, target, finished) //create and display the camera snapshots continuously
{
	var img = new Image();
	var d = new Date();
	
	if (finished==undefined) // First time loadCamImage is called, finished will not be defined
	{
		finished = new Array(); // References to img objects which have finished downloading		
	}
	
	img.style.position = "absolute";

	// When image is loaded
	$(img).load(function() {

		// If active id is different, stop processing. This means the user switched cam, so another process with the other ID have started
		// OR if the placeholder does not exist anymore stop as well.			
		if ($(target).attr("activeid")!=id || $(target).length==0) 
		{ return; }
			
		var placeHolderHeight = this.height;   // Takes the image height
	
		// Resize the image, if needed
		placeHolderWidth = $(target).width();  // Takes the placeHolder Width
		if (this.width > placeHolderWidth) // If image width is bigger than the div width, resize the image.
		{
			// Resize the image width;
			this.style.width = placeHolderWidth+"px";
	
			// If we have to resize the picture width, this also means that the placeHolder height should be shorter by the same ratio.
			placeHolderHeight *= placeHolderWidth / this.width;
		}
	
		// Sets the div height height to the maximum image size
		$(target).attr("style", "height:" + placeHolderHeight + "px;");  
	
		$(this).prependTo(target); // Actually displays the loaded image
	
		while (finished.length > 1) // We keep 2 images in the backgroud to eliminate flicker
		{
			var del = finished.shift(); // Delete old image(s) from document
			if (del.parentNode != null)
			{
				del.parentNode.removeChild(del);
			}
		}
		finished.push(this);

		loadCamImage(id, urlSet, currentUrlIndex, target, finished.splice(0));
	});

	// If image does not load
	$(img).error(function() {
		// If active id is different, stop processing. This means the user switched cam, so another process with the other ID have started
		// OR if the placeholder does not exist anymore stop as well.			
		if ($(target).attr("activeid")!=id || $(target).length==0) 
		{ return; }

		// Alternate between the 2 url;
		currentUrlIndex+=1;
		currentUrlIndex%=urlSet.length; 
					
		loadCamImage(id, urlSet, currentUrlIndex, target, finished.splice(0)); // When image is loaded and displays, retriggers display of a new		
	});

	
	var str = urlSet[currentUrlIndex] + d.getTime(); 
//	console.log("URL: " + str);
	img.src = str;  // This trigers image loading
}


function hostname(url)
{
    if (!url) url = "";

	var host = url.replace('http://','').replace('https://','').split(/[/?#]/)[0];
	
	startIndex = host.indexOf("@");
	
	if (startIndex!=-1)
		host = host.substr(startIndex+1) // Remove user/password at start of Domain, if present
		
	host = host.split(":")[0]; // Remove port, if present.

	return host;
}


function senseIP(ip, timeout)
{
    var deferred = $.Deferred();
    var promise = deferred.promise();
	var senseImg = new Image();

	function endTimer()
	{
		if (!pingEnd)  // will run only once, no matter if which event kicked in
		{
			pingEnd=$.now();
			var ping = pingEnd - pingStart;
	        deferred.resolve(ping);			
		}
	}

	$(senseImg).load(function() { endTimer() });
	$(senseImg).error(function() { endTimer() });
	setTimeout(function(){ endTimer() }, timeout);
			
	var pingStart = $.now();
	var pingEnd = 0;

	senseImg.src = "http://" + ip + "/?cachebreaker="+new Date().getTime();
	
	return promise;
}
