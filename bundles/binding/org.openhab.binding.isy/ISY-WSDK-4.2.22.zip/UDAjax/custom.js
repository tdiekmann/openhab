/*
*  ISY994 AJAX Custom js
*  Author: Benoit Mercier
*
* User Defined Functions should be included here
*/

// Control over when rest calls are done
// 1 = At page load, 
// 2 = When switching to the corresponding tab
// 0 = Do not load. The corresponding UDF will not run.
var loadConfig = 0; // Set to 1 to load /rest/config at startup.
var loadDevs = 1; // Set to 1 to load /rest/nodes at startup.
var loadVar1Defs = 2; // Set to 1 if some integer variable names are used in a custom table. Set to 0 or 2 for better performance.
var loadVar2Defs = 2; // Set to 1 if some state variable names are used in a custom table. Set to 0 or 2 for better performance.
var loadVar1Data = 2; // Set to 1 to load integer variable data and run UDFvarDataLoaded at page load time. 
var loadVar2Data = 2; // Set to 1 to load state variable data and run UDFvarDataLoaded at page load time. 
var loadPgms = 2; // Set to 1 if some program names are used in a custom table. Set to 0 or 2 for better performance.

// Refresh Delays (in milliseconds)
var noerrFeedbackDelay = 800; // Delay before removing a successful feedback message
var devRefreshDelay = 800;  // Delay to update the table item after a change for a device
var devRefreshDelay2 = 3000;  // Delay to update the table item  - 2nd refresh (Set to 0 for no 2nd refresh)
var devRefreshDelay3 = 6000;  // Delay to update the table item - 3rd refresh (Set to 0 for no 3rd refresh)
var varRefreshDelay = 100;  // Delay to update the table item if refreshOpt==Var
var pgmRefreshDelay = 100;  // Delay to update the table item if refreshOpt==Pgm
var thermRefreshDelay = 4000;  // Delay to update the table item if this is a thermostat
var wholeTableRefreshDelay = 800;  // Delay for a full table refresh, after a change if refreshOpt=="All"
var automaticDevRefreshDelay = 20000 // Delay between each device table refresh. 0 = No refresh.

// Other delays
var thermDelay = 500;  // Will process temperature changes only after the users stops pressing buttons for x ms

//Thermostat controls min/max
var thermHeatMax = 80; // Max heating temp allowed
var thermHeatMin = 5; // Min heating temp allowed
var thermCoolMax = 80; // Max cooling temp allowed
var thermCoolMin = 5; // Min cooling temp allowed

var camConfigLocation = "/web/"
var camConfigLocationUpload = "/file/upload/web/"

var deviceTabs = [ "tabs-dev" ]; //Tabs when Automatic refresh should be active


// Runs as soon as the web page is loaded, before making any rest calls
function UDFinit() 
{ 
	var radio = "#UdajaxHadToggle"
	
	if (loadConfig==1) 
	{
		restCallConfig(); 	// UDFconfigLoaded will be called when rest call is complete.
	}

	if (loadDevs==1) 
	{
		restCallNodes(); // UDFdevLoaded will be called when rest call is complete.
	}	

	if ($.cookie('redirectOption')) {
		redirectOption = parseInt($.cookie('redirectOption')); 
	}

	$(radio + redirectOption).attr('checked', 'checked');	
	$(radio).buttonset();				
} 

// This is run when /rest/config is loaded successfully
function UDFconfigLoaded(configdata) 
{ 
	processConfig(configdata);
} 


// This is run when /rest/node is loaded successfully
function UDFdevLoaded(devdata)
{
	var deferredVarsDefWhen=0;
		
	//We wait until /rest/nodes is loaded before initiating other rest calls	
	if (loadVar1Defs==1 || loadVar2Defs==1)
	{
		deferredVarsDefWhen = restCallVarsDef(loadVar1Defs==1, loadVar2Defs==1);
		// UDFvarsDefLoaded will be called when rest calls are complete.
	}

	if (loadPgms==1) // If enabled, start this Ajax request ASAP, it will run in parallel with the current thread.
	{
		restCallPgms(deferredVarsDefWhen);
		// UDFpgmLoaded will be called when rest call is complete.
	}
		
	if (loadVar1Data==1 || loadVar2Data==1)
	{
		restCallVarsData(loadVar1Data==1, loadVar2Data==1, deferredVarsDefWhen)
		// UDFvarDataLoaded will be called when rest calls are complete.		
	}

	// Buils the generic table list 
	tableBuildDeviceList(devdata, devListDefault, "All");

	// Process templates without waiting for programs and variable data. It takes too long. The page gets updated later automatically.		
	processTemplate("#defaultDeviceListPlaceholder", devListDefault, "deviceListTemplate");
}


// This is run when /rest/node has completed with error
function UDFdevLoadingError(){}


// This is run when /rest/node has completed (successfully or not) and the UI has initialized (Sliders, Spinners, Buttons, etc)
// If /rest/node was not successful, devdata data is not passed to the function
function UDFdevLoadedPostUI(devdata)
{ 
	// Groups buttons together	
	$("#isybuttonset").buttonset();	

	$("[slid]").slider("option", "animate", "slow"); // Enable slider animation.
}



// This is run when variable definitions are all loaded successfully. 
//	vars1data comes from /rest/vars/definitions/1 
//	vars2data comes from /rest/vars/definitions/2 
function UDFvarsDefLoaded(vars1def, vars2def)
{
	// Buils and displays the generic variables list 	
	if (vars1def)
	{
		tableBuildVarList(vars1def, varListDefault, "Integer variables", "1"); // Creates a first section with name "Integer variables" 
	}
	
	if (vars2def)
	{
		tableBuildVarList(vars2def, varListDefault, "State variables", "2");  // Adds a second section with name "State variables"			
	}
	
	processTemplate("#defaultVarListPlaceholder", varListDefault, "deviceListTemplate");
	
	// For each typeControl=Var: when a variable name was specified instead of type+id, updates the buttons with appropriate  names to id's
	processVarButtons(vars1def, vars2def); 

	// Inits the variable sliders
	initVarSliders(); 		// Currently, does not support variables specified by name. Requires Type, Id, and also varMax.
}


// This is run when programs and variable definitions are all loaded successfully. 
//  pgmdata comes from /rest/programs/?subfolders=true
//	vars1data comes from /rest/vars/definitions/1 
//	vars2data comes from /rest/vars/definitions/2 
function UDFpgmLoaded(pgmdata, vars1def, vars2def)
{
	// Buils and displays the generic program list 
	tableBuildPgmList(pgmdata, pgmListDefault, "All");	// Creates the table with all folders 
	processTemplate("#defaultPgmListPlaceholder", pgmListDefault, "deviceListTemplate");

	// For each typeControl=Program: Updates the buttons when needed
//	processPgmButtons(pgmdata, vars1def, vars2def); 

	pgmUpdateAllStatus(pgmdata);  // If we can supply pgmdata, the screen update is faster
}


// This is run when variable data is loaded successfully. 
function UDFvarDataLoaded(vars1data, vars2data, vars1def, vars2def)
{	
	varUpdateAllStatus(vars1data, vars2data);  // Updates all var statuses in variable general table, and custom tables.	
}



var devsLoaded=0;  // Will be set to one once loaded.
var varsDefLoaded=0;  // Will be set to one once loaded.
var pgmsLoaded=0;  // Will be set to one once loaded.

// Runs when we switch tabs.
// Careful, this runs as soon as the UI is ready. This will run before any rest calls is done.
function UDFtabActivated(event, ui)  
{
	var activeTab = ui.newPanel.attr('id');
	var oldTab = "";

	if (ui.oldPanel!=null)  
	{
		oldTab = ui.oldPanel.attr('id'); 
	}

	if ($.inArray(activeTab, deviceTabs)!=-1) // If this is a device tab
	{
		if ((loadDevs==1 && oldTab) || (loadDevs==2 && devsLoaded))
		{
			startAutomaticDevRefresh();			
		}
		else if (loadDevs==2 && !devsLoaded)
		{
			restCallNodes(); 
			// UDFdevLoaded will be called when rest call is complete.
			// Note: Automatic refresh will be started in UDFdecLoaded

			devsLoaded=1;		
			startAutomaticDevRefresh(automaticDevRefreshDelay); // Do not refresh now, wait refresh delay to start
		}
		else if (loadDevs==1 && !oldTab)
		{
			startAutomaticDevRefresh(automaticDevRefreshDelay); // Do not refresh now, wait refresh delay to start			
		}
	}
	else
	{
		stopAutomaticDevRefresh();	
	}
	
	if (activeTab == "tabs-var")
	{	
		var deferred=null;
			
		if (!varsDefLoaded) // Will run only once
		{
			if (loadVar1Defs==2 || loadVar2Defs==2)
			{
				deferred = restCallVarsDef(loadVar1Defs==2, loadVar2Defs==2);
				// UDFvarsDefLoaded will be called when rest calls are complete.
			}
				
			varsDefLoaded=1; // We consider it loaded. (It may have been loaded at page load time)	
		}
	
		if (loadVar1Data || loadVar2Data)  // If set to 1 or 2, we do refresh.
		{
			restCallVarsData(loadVar1Data, loadVar2Data, deferred) 
			// deferred needs to be passed, otherwise UDFvarDataLoaded could run before UDFvarsDefLoaded
			// UDFvarDataLoaded will be called when rest calls are complete.
		}	
	}
	else if (activeTab == "tabs-pgm")
	{	
		if (pgmsLoaded || loadPgms==1) // If already loaded || was loaded at init time
		{
			pgmUpdateAllStatus() // Refresh
		}		
		else 
		{
			if (loadPgms==2)
			{
				restCallPgms();
				// UDFpgmLoaded will be called when rest call is complete.
				pgmsLoaded=1;
			}	
		}
	}
	else if (activeTab == "tabs-weather")
	{
		getWeather();
	}
	else if (activeTab == "tabs-cam")
	{
		initCams();
    }

	// Runs on a switch of tab only (not during tabCreated event)
	if (ui.oldPanel!=null)  
	{
		oldTab = ui.oldPanel.attr('id');	
		
	    if (oldTab == "tabs-cam")  // Stop processing cam if tab is not activated
		{		
			stopCams();
	    }		
	}
}




// Called after choosing a new default home page
function redirectHomePage(option)   // 0=UDAjax 1=HAD
{
	var url = "index.htm"; // Redirector URL
	
	$.cookie('redirectOption',option, { path: '/'});
	
	feedback("Loading " + url);
	setTimeout("location.href = '" + url + "'", 800);	// Leave feedback on screen 800ms then redirect
}

